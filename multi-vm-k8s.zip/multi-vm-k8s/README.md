# Hyperledger Fabric on Kubernetes (multi-node)

Deploy a minimal Fabric network (orderer + 2 peers) on Kubernetes with fixed node placement. Chaincode runs as an external service (no Docker in peer pods).

**Paths in this guide use `/home/djahid`.** If your home directory is different, replace it. We assume:
- `fabric-samples` is at `/home/djahid/fabric-samples`
- This directory (`multi-vm-k8s`) is at `/home/djahid/fabric-samples/multi-vm-k8s`

| Component   | Pod         | Node (edit YAML if yours differ) |
|------------|-------------|-----------------------------------|
| Orderer    | orderer     | worker2 (desktop-worker2)         |
| Peer0 Org1 | peer0-org1  | control-plane (desktop-control-plane) |
| Peer0 Org2 | peer0-org2  | worker1 (desktop-worker)          |

**Three physical nodes (each with its own IP):** The same approach applies. Peers and the orderer communicate via Kubernetes Services and cluster DNS, not node IPs. You do **not** need to add anything to `/etc/hosts` on the nodes or on your laptop. When using port-forward, you connect to `localhost`; TLS hostname override handles cert verification.

---

## Prerequisites

- Kubernetes cluster with at least 3 nodes. Edit `affinity` in `orderer.yaml`, `peer0-org1.yaml`, and `peer0-org2.yaml` if your node names differ.
- Fabric binaries and config. From the **parent** of `fabric-samples`:
  ```bash
  curl -sSLO https://raw.githubusercontent.com/hyperledger/fabric/main/scripts/install-fabric.sh && chmod +x install-fabric.sh
  ./install-fabric.sh binary docker
  ```
- Generate crypto and genesis block:
  ```bash
  cd /home/djahid/fabric-samples/test-network
  ./network.sh up
  ```

---

## Step 1: Create Kubernetes secrets

```bash
cd /home/djahid/fabric-samples/multi-vm-k8s
chmod +x create-fabric-secrets.sh
./create-fabric-secrets.sh
```

Optionally set `TEST_NETWORK_PATH=/home/djahid/fabric-samples/test-network` and `FABRIC_NS=fabric` if your layout differs.

---

## Step 2: Apply manifests

```bash
kubectl apply -f namespace.yaml
kubectl apply -f orderer.yaml
kubectl apply -f peer0-org1.yaml
kubectl apply -f peer0-org2.yaml
```

Verify pods (and node placement if desired):

```bash
kubectl get pods -n fabric -o wide
```

---

## Step 3: Port-forward (required for channel and chaincode from host)

Keep these running in the background (or in a separate terminal):

```bash
kubectl -n fabric port-forward svc/orderer-example-com 7050:7050 &
kubectl -n fabric port-forward svc/peer0-org1-example-com 7051:7051 &
kubectl -n fabric port-forward svc/peer0-org2-example-com 9051:9051 &
```

---

## Step 4: Create channel

All peer and configtxgen commands in this and the following steps are run from **test-network** so `organizations/` and `configtx/` are present.

```bash
cd /home/djahid/fabric-samples/test-network
mkdir -p channel-artifacts
export CHANNEL_NAME=mychannel2
export ORDERER_CA=$PWD/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PEER0_ORG1_CA=$PWD/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export PEER0_ORG2_CA=$PWD/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt
```

Create channel transaction (configtxgen uses `configtx/`):

```bash
export FABRIC_CFG_PATH=$PWD/configtx
configtxgen -profile TwoOrgsChannel -outputCreateChannelTx ./channel-artifacts/mychannel2.tx -channelID mychannel2
```

Create channel (peer uses `../config` for core.yaml):

```bash
export FABRIC_CFG_PATH=$PWD/../config
peer channel create -o localhost:7050 -c mychannel2 -f ./channel-artifacts/mychannel2.tx --outputBlock ./channel-artifacts/mychannel2.block --tls --cafile $ORDERER_CA --ordererTLSHostnameOverride orderer.example.com
```

---

## Step 5: Join peers to channel

```bash
export FABRIC_CFG_PATH=$PWD/../config
```

Org1:

```bash
export CORE_PEER_ADDRESS=localhost:7051
export CORE_PEER_LOCALMSPID=Org1MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
peer channel join -b ./channel-artifacts/mychannel2.block
```

Org2:

```bash
export CORE_PEER_ADDRESS=localhost:9051
export CORE_PEER_LOCALMSPID=Org2MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp
peer channel join -b ./channel-artifacts/mychannel2.block
```

Confirm (optional):

```bash
peer channel list
peer channel getinfo -c mychannel2
```

---

## Step 6: Deploy external chaincode (asset-transfer-basic)

### 6.1 Apply external builder and restart peers

```bash
kubectl apply -f /home/djahid/fabric-samples/multi-vm-k8s/chaincode-external-builder.yaml -n fabric
kubectl rollout restart deployment/peer0-org1 deployment/peer0-org2 -n fabric
```

Wait for pods to be ready.

### 6.2 Build chaincode image

On a machine with Docker (Docker Desktop K8s can use the same daemon; remote clusters need a registry):

```bash
cd /home/djahid/fabric-samples/asset-transfer-basic/chaincode-external
docker build -t asset-transfer-basic:1.0 .
```

For a remote cluster, tag and push to your registry and set that image in `chaincode-basic.yaml`.

### 6.3 Create external package and deploy chaincode pod

```bash
cd /home/djahid/fabric-samples/multi-vm-k8s
chmod +x package-cc-external.sh
./package-cc-external.sh basic 1.0
kubectl apply -f chaincode-basic.yaml -n fabric
```

### 6.4 Install package on both peers

From test-network (port-forwards must be active):

```bash
cd /home/djahid/fabric-samples/test-network
export FABRIC_CFG_PATH=$PWD/../config
export PEER0_ORG1_CA=$PWD/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
export PEER0_ORG2_CA=$PWD/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt
```

Org1:

```bash
export CORE_PEER_ADDRESS=localhost:7051
export CORE_PEER_LOCALMSPID=Org1MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
peer lifecycle chaincode install /home/djahid/fabric-samples/multi-vm-k8s/basic_1.0.tar.gz
```

Org2:

```bash
export CORE_PEER_ADDRESS=localhost:9051
export CORE_PEER_LOCALMSPID=Org2MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp
peer lifecycle chaincode install /home/djahid/fabric-samples/multi-vm-k8s/basic_1.0.tar.gz
```

### 6.5 Get Package ID and set in chaincode deployment

```bash
export CORE_PEER_ADDRESS=localhost:7051
export CORE_PEER_LOCALMSPID=Org1MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
peer lifecycle chaincode queryinstalled
```

Copy the Package ID (e.g. `basic_1.0:59ef6e0a2e6cc...`). Edit `chaincode-basic.yaml`: set the `CHAINCODE_ID` env value to that Package ID. Then:

```bash
kubectl apply -f /home/djahid/fabric-samples/multi-vm-k8s/chaincode-basic.yaml -n fabric
kubectl rollout restart deployment/basic-cc -n fabric
```

### 6.6 Approve and commit chaincode

Set common variables (still in test-network):

```bash
export CHANNEL_NAME=mychannel2
export CC_NAME=basic
export CC_VERSION=1.0
export CC_SEQUENCE=1
export ORDERER_CA=$PWD/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PACKAGE_ID=<paste-the-package-id-from-queryinstalled>
```

Approve for Org1:

```bash
export CORE_PEER_ADDRESS=localhost:7051
export CORE_PEER_LOCALMSPID=Org1MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name $CC_NAME --version $CC_VERSION --package-id $PACKAGE_ID --sequence $CC_SEQUENCE
```

Approve for Org2:

```bash
export CORE_PEER_ADDRESS=localhost:9051
export CORE_PEER_LOCALMSPID=Org2MSP
export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
export CORE_PEER_MSPCONFIGPATH=$PWD/organizations/peerOrganizations/org2.example.com/users/Admin@org2.example.com/msp
peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name $CC_NAME --version $CC_VERSION --package-id $PACKAGE_ID --sequence $CC_SEQUENCE
```

Commit:

```bash
peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name $CC_NAME --version $CC_VERSION --sequence $CC_SEQUENCE --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA
```

---

## Step 7: Invoke and query chaincode

Seed ledger (do **not** use `--isInit`; InitLedger is a normal function):

```bash
peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile $ORDERER_CA -C $CHANNEL_NAME -n $CC_NAME --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA -c '{"function":"InitLedger","Args":[]}'
```

Query all assets:

```bash
peer chaincode query -C $CHANNEL_NAME -n $CC_NAME -c '{"Args":["GetAllAssets"]}'
```

---

## Optional: DNS for TLS (cluster-admin)

If you can edit CoreDNS, add rewrite rules so `orderer.example.com` and peer hostnames resolve to Fabric services. See `coredns-fabric-rewrite.yaml` for the three rewrite lines. Add them inside the `.:53` block (before `forward`), then:

```bash
kubectl rollout restart deployment coredns -n kube-system
```

Then you can run channel/chaincode from a pod in the cluster using service names instead of port-forward.

---

## Customizing node names

If your node names differ from `desktop-control-plane`, `desktop-worker`, `desktop-worker2`, edit the `affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[].matchFields[].values` in:
- `orderer.yaml`
- `peer0-org1.yaml`
- `peer0-org2.yaml`
