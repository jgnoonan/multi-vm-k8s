#!/usr/bin/env bash
#
# Copyright IBM Corp. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Creates Kubernetes secrets from test-network crypto material and genesis block.
# Run from fabric-samples/test-network: ./network.sh up
# Then run this script from multi-vm-k8s (or set TEST_NETWORK_PATH, e.g. /home/djahid/fabric-samples/test-network).
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_NETWORK_PATH="${TEST_NETWORK_PATH:-${SCRIPT_DIR}/../test-network}"
FABRIC_NS="${FABRIC_NS:-fabric}"

if [ ! -f "${TEST_NETWORK_PATH}/system-genesis-block/genesis.block" ]; then
  echo "Genesis block not found. Generate crypto first:"
  echo "  cd ${TEST_NETWORK_PATH} && ./network.sh up"
  exit 1
fi

echo "Using test-network at: ${TEST_NETWORK_PATH}"
echo "Namespace: ${FABRIC_NS}"

kubectl create namespace "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -

# Orderer genesis block (single key genesis.block)
kubectl create secret generic orderer-genesis-block \
  --from-file=genesis.block="${TEST_NETWORK_PATH}/system-genesis-block/genesis.block" \
  -n "${FABRIC_NS}" \
  --dry-run=client -o yaml | kubectl apply -f -

# Create tarballs so directory structure is preserved in secrets (K8s secret keys are flat)
ORDERER_BASE="${TEST_NETWORK_PATH}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com"
TMPDIR="${TMPDIR:-/tmp}/fabric-k8s-secrets-$$"
mkdir -p "${TMPDIR}"
trap "rm -rf ${TMPDIR}" EXIT

( cd "${ORDERER_BASE}" && tar -czf "${TMPDIR}/orderer-msp.tar.gz" msp )
( cd "${ORDERER_BASE}" && tar -czf "${TMPDIR}/orderer-tls.tar.gz" tls )
kubectl create secret generic orderer-msp --from-file=msp.tar.gz="${TMPDIR}/orderer-msp.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -
kubectl create secret generic orderer-tls --from-file=tls.tar.gz="${TMPDIR}/orderer-tls.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -

# Peer0 Org1
ORG1_BASE="${TEST_NETWORK_PATH}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com"
( cd "${ORG1_BASE}" && tar -czf "${TMPDIR}/peer0-org1-msp.tar.gz" msp )
( cd "${ORG1_BASE}" && tar -czf "${TMPDIR}/peer0-org1-tls.tar.gz" tls )
kubectl create secret generic peer0-org1-msp --from-file=msp.tar.gz="${TMPDIR}/peer0-org1-msp.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -
kubectl create secret generic peer0-org1-tls --from-file=tls.tar.gz="${TMPDIR}/peer0-org1-tls.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -

# Peer0 Org2
ORG2_BASE="${TEST_NETWORK_PATH}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com"
( cd "${ORG2_BASE}" && tar -czf "${TMPDIR}/peer0-org2-msp.tar.gz" msp )
( cd "${ORG2_BASE}" && tar -czf "${TMPDIR}/peer0-org2-tls.tar.gz" tls )
kubectl create secret generic peer0-org2-msp --from-file=msp.tar.gz="${TMPDIR}/peer0-org2-msp.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -
kubectl create secret generic peer0-org2-tls --from-file=tls.tar.gz="${TMPDIR}/peer0-org2-tls.tar.gz" -n "${FABRIC_NS}" --dry-run=client -o yaml | kubectl apply -f -

echo "Secrets created in namespace ${FABRIC_NS}. Deploy with: kubectl apply -f . -n ${FABRIC_NS}"
echo "Placement: orderer→worker2, peer0-org1→master, peer0-org2→worker1"
